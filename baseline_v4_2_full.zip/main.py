import tkinter as tk
from tkinter import ttk
from connection_tab import ConnectionTab
from editor_tab import EditorTab
from run_tab import RunTab

class TestManagerApp:
    def __init__(self, root):
        self.root = root
        self.root.title("QA Test Manager v2.0")

        # Notebook (tabbed interface)
        self.notebook = ttk.Notebook(root)
        self.notebook.pack(fill="both", expand=True)

        # Tabs
        self.connection_tab = ConnectionTab(self.notebook)
        self.editor_tab = EditorTab(self.notebook)
        self.run_tab = RunTab(self.notebook, self.editor_tab)

        # Add tabs to notebook
        self.notebook.add(self.connection_tab.frame, text="Connection")
        self.notebook.add(self.editor_tab.frame, text="Editor")
        self.notebook.add(self.run_tab.frame, text="Run & Export")

if __name__ == "__main__":
    root = tk.Tk()
    app = TestManagerApp(root)
    root.mainloop()
