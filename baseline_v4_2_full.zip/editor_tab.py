import tkinter as tk
from tkinter import ttk, filedialog, messagebox
import json

class EditorTab:
    def __init__(self, notebook):
        self.frame = ttk.Frame(notebook)
        self.data = []

        # Buttons
        button_frame = ttk.Frame(self.frame)
        button_frame.pack(fill="x")

        ttk.Button(button_frame, text="Load JSON", command=self.load_json).pack(side="left", padx=5, pady=5)
        ttk.Button(button_frame, text="Save JSON", command=self.save_json).pack(side="left", padx=5, pady=5)
        ttk.Button(button_frame, text="Add Command", command=self.add_command).pack(side="left", padx=5, pady=5)
        ttk.Button(button_frame, text="Duplicate", command=self.duplicate_row).pack(side="left", padx=5, pady=5)
        ttk.Button(button_frame, text="Delete", command=self.delete_row).pack(side="left", padx=5, pady=5)

        # Table
        cols = ("Command Name","Command","Expected","Negative","Wait Till","Print After","Print Ahead Chars","Message","Regex")
        self.tree = ttk.Treeview(self.frame, columns=cols, show="headings", selectmode="browse")
        for col in cols:
            self.tree.heading(col, text=col)
            self.tree.column(col, width=120, stretch=True)
        self.tree.pack(fill="both", expand=True)

        self.tree.bind("<<TreeviewSelect>>", self.on_row_select)
        self.tree.bind("<B1-Motion>", self.drag)
        self.tree.bind("<ButtonRelease-1>", self.drop)

        # Edit section
        self.edit_frame = ttk.LabelFrame(self.frame, text="Edit Command")
        self.edit_frame.pack(fill="x", pady=5)

        self.edit_vars = {col: tk.StringVar() for col in cols}
        row1 = ttk.Frame(self.edit_frame)
        row2 = ttk.Frame(self.edit_frame)
        row3 = ttk.Frame(self.edit_frame)
        row1.pack(fill="x", pady=2)
        row2.pack(fill="x", pady=2)
        row3.pack(fill="x", pady=2)

        # distribute fields across rows for better layout
        for i, col in enumerate(cols):
            row = row1 if i<3 else row2 if i<6 else row3
            ttk.Label(row, text=col).pack(side="left", padx=5)
            ttk.Entry(row, textvariable=self.edit_vars[col], width=20).pack(side="left", padx=5)

        self.save_edit_btn = ttk.Button(self.edit_frame, text="Save Edit", command=self.save_edit, state="disabled")
        self.save_edit_btn.pack(pady=5)

        self.dragging_index = None

    def load_json(self):
        file_path = filedialog.askopenfilename(filetypes=[("JSON files","*.json")])
        if not file_path: return
        with open(file_path) as f:
            self.data = json.load(f)
        self.refresh_table()

    def save_json(self):
        file_path = filedialog.asksaveasfilename(defaultextension=".json", filetypes=[("JSON files","*.json")])
        if not file_path: return
        with open(file_path,"w") as f:
            json.dump(self.data,f,indent=2)
        messagebox.showinfo("Saved", f"Commands saved to {file_path}")

    def add_command(self):
        cmd = {
            "Command Name": "New Command",
            "Command": "",
            "Expected": "",
            "Negative": "",
            "Wait Till": "1",
            "Print After": "0",
            "Print Ahead Chars": "0",
            "Message": "",
            "Regex": ""
        }
        self.data.append(cmd)
        self.refresh_table()

    def duplicate_row(self):
        selected = self.tree.selection()
        if not selected: return
        index = self.tree.index(selected[0])
        self.data.insert(index+1, dict(self.data[index]))
        self.refresh_table()

    def delete_row(self):
        selected = self.tree.selection()
        if not selected: return
        index = self.tree.index(selected[0])
        del self.data[index]
        self.refresh_table()

    def on_row_select(self, event):
        selected = self.tree.selection()
        if not selected: return
        index = self.tree.index(selected[0])
        cmd = self.data[index]
        for k,v in self.edit_vars.items():
            v.set(cmd.get(k,""))
        self.save_edit_btn["state"] = "normal"

    def save_edit(self):
        selected = self.tree.selection()
        if not selected: return
        index = self.tree.index(selected[0])
        for k,v in self.edit_vars.items():
            self.data[index][k] = v.get()
        self.refresh_table()
        self.save_edit_btn["state"] = "disabled"

    def refresh_table(self):
        for row in self.tree.get_children():
            self.tree.delete(row)
        for cmd in self.data:
            self.tree.insert("", "end", values=[cmd.get(col,"") for col in self.tree["columns"]])

    # drag/drop reorder
    def drag(self, event):
        row = self.tree.identify_row(event.y)
        if row:
            self.dragging_index = self.tree.index(row)

    def drop(self, event):
        if self.dragging_index is None: return
        row = self.tree.identify_row(event.y)
        if row:
            new_index = self.tree.index(row)
            if new_index != self.dragging_index:
                self.data.insert(new_index, self.data.pop(self.dragging_index))
                self.refresh_table()
        self.dragging_index = None
