import tkinter as tk
from tkinter import ttk, messagebox, filedialog
import time, threading, re
from export_utils import export_to_html

class RunTab:
    def __init__(self, notebook, editor_tab):
        self.frame = ttk.Frame(notebook)
        self.editor_tab = editor_tab
        self.running = False
        self.stop_flag = False
        self.iterations = 1
        self.results = []

        # Top bar
        top_frame = ttk.Frame(self.frame)
        top_frame.pack(fill="x")

        ttk.Label(top_frame, text="Iterations:").pack(side="left", padx=5)
        self.iter_var = tk.IntVar(value=1)
        ttk.Entry(top_frame, textvariable=self.iter_var, width=5).pack(side="left", padx=5)

        self.run_button = ttk.Button(top_frame, text="Run All", command=self.run_all)
        self.run_button.pack(side="left", padx=5)

        self.stop_button = ttk.Button(top_frame, text="Stop", command=self.stop_all)
        self.stop_button.pack(side="left", padx=5)

        self.export_button = ttk.Button(top_frame, text="Export HTML", command=self.export_html, state="disabled")
        self.export_button.pack(side="left", padx=5)

        # Results table
        self.tree = ttk.Treeview(
            self.frame,
            columns=("Command Name","Command","Expected","Found","Result","Snippet","Message","Iteration"),
            show="headings"
        )
        for col in self.tree["columns"]:
            self.tree.heading(col, text=col)
            self.tree.column(col, width=120, stretch=True)
        self.tree.pack(fill="both", expand=True)

        # Live logs
        self.log_text = tk.Text(self.frame, height=10, bg="black", fg="white")
        self.log_text.pack(fill="x", padx=5, pady=5)

    def log(self, msg):
        timestamp = time.strftime("%H:%M:%S")
        line = f"[{timestamp}] {msg}\n"
        self.log_text.insert(tk.END, line)
        self.log_text.see(tk.END)
        with open("session.log", "a") as f:
            f.write(line)

    def run_all(self):
        if self.running:
            messagebox.showwarning("Running", "Tests already running.")
            return
        self.stop_flag = False
        self.iterations = self.iter_var.get()
        self.results = []

        # Show all test cases in gray first
        self.refresh_table(initial=True)

        self.running = True
        threading.Thread(target=self._execute_tests, daemon=True).start()

    def stop_all(self):
        self.stop_flag = True
        self.log("[INFO] Stop requested by user.")

    def _execute_tests(self):
        for iteration in range(1, self.iterations+1):
            for index, cmd in enumerate(self.editor_tab.data):
                if self.stop_flag:
                    self.running = False
                    return

                # Update row color → Yellow (running)
                self.update_row_color(index, "yellow")

                self.log(f"Executing {cmd['Command Name']} (Iteration {iteration})")

                time.sleep(int(cmd.get("Wait Till", 1)))  # simulate wait

                output = f"Simulated output for {cmd['Command']}"
                found = False
                result = "FAIL"

                expected = cmd.get("Expected", "")
                regex = cmd.get("Regex", "")

                if expected and expected in output:
                    found, result = True, "PASS"
                elif regex:
                    try:
                        if re.search(regex, output):
                            found, result = True, "PASS"
                    except re.error as e:
                        self.log(f"[ERROR] Invalid regex: {e}")

                snippet = output[:50]
                row_result = {
                    "Command Name": cmd.get("Command Name",""),
                    "Command": cmd.get("Command",""),
                    "Expected": expected,
                    "Found": "YES" if found else "NO",
                    "Result": result,
                    "Snippet": snippet,
                    "Message": cmd.get("Message",""),
                    "Iteration": iteration
                }
                self.results.append(row_result)

                # Update row color → Green or Red
                self.update_row_result(index, row_result)

                # Enable export after 1st test executed
                if self.export_button["state"] == "disabled":
                    self.export_button["state"] = "normal"

        self.running = False
        self.log("[INFO] All tests finished.")

    def refresh_table(self, initial=False):
        for row in self.tree.get_children():
            self.tree.delete(row)
        for cmd in self.editor_tab.data:
            values = (
                cmd.get("Command Name",""), cmd.get("Command",""), cmd.get("Expected",""),
                "", "", "", cmd.get("Message",""), ""
            )
            item_id = self.tree.insert("", "end", values=values)
            if initial:
                self.tree.item(item_id, tags=("gray",))
        self.tree.tag_configure("gray", background="lightgray")

    def update_row_color(self, index, color):
        item_id = self.tree.get_children()[index]
        self.tree.item(item_id, tags=(color,))
        self.tree.tag_configure("yellow", background="yellow")

    def update_row_result(self, index, row_result):
        item_id = self.tree.get_children()[index]
        values = (
            row_result["Command Name"], row_result["Command"], row_result["Expected"],
            row_result["Found"], row_result["Result"], row_result["Snippet"],
            row_result["Message"], row_result["Iteration"]
        )
        self.tree.item(item_id, values=values)
        tag = "green" if row_result["Result"]=="PASS" else "red"
        self.tree.item(item_id, tags=(tag,))
        self.tree.tag_configure("green", background="lightgreen")
        self.tree.tag_configure("red", background="tomato")

    def export_html(self):
        file_path = filedialog.asksaveasfilename(defaultextension=".html", filetypes=[("HTML files","*.html")])
        if not file_path: return
        export_to_html(file_path, self.results)
        messagebox.showinfo("Exported", f"Results exported to {file_path}")
