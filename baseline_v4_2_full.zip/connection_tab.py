import tkinter as tk
from tkinter import ttk

class ConnectionTab:
    def __init__(self, notebook):
        self.frame = ttk.Frame(notebook)

        # Port selection label + dropdown
        self.port_label = ttk.Label(self.frame, text="Select Port:")
        self.port_label.pack(pady=5)

        self.port_var = tk.StringVar()
        self.port_dropdown = ttk.Combobox(self.frame, textvariable=self.port_var)
        self.port_dropdown["values"] = ["COM1", "COM2", "COM3", "COM4"]
        self.port_dropdown.current(0)
        self.port_dropdown.pack(pady=5)

        # Connect button
        self.connect_button = ttk.Button(self.frame, text="Connect", command=self.connect)
        self.connect_button.pack(pady=10)

    def connect(self):
        # In real app → serial connection logic
        print(f"[INFO] Connected to port: {self.port_var.get()}")
